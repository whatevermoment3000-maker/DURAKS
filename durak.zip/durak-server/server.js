'use strict';
/*
  Дурак: Black Market — сервер-шина.
  Хранит аккаунты, сессии и столы, ведёт партии и рассылает каждому игроку
  его личный вид стола (свои карты видны, чужие — нет) через поток событий (SSE).
  Без внешних зависимостей: нужен только Node.js 18+.
*/
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const E = require('./engine.js');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const SESSION_DAYS = 30;
const MAX_ACTIVE_TABLES = 6;

/* ---------------- storage ---------------- */
fs.mkdirSync(DATA_DIR, { recursive: true });
let db = { users: {}, sessions: {}, tables: {} };
try {
  db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
} catch (e) {
  if (e.code !== 'ENOENT') { console.error('Не удалось прочитать базу:', e.message); process.exit(1); }
}
/* admin bootstrap: ADMIN_LOGIN + ADMIN_PASSWORD from environment */
(function ensureAdmin() {
  const login = String(process.env.ADMIN_LOGIN || '').trim();
  const pw = String(process.env.ADMIN_PASSWORD || '');
  if (!login || !pw) return;
  const id = login.toLowerCase();
  let u = db.users[id];
  if (!u) {
    const salt = crypto.randomBytes(16).toString('hex');
    u = db.users[id] = { id, name: login, salt, hash: crypto.scryptSync(pw, salt, 64).toString('hex'), created: Date.now(), w: 0, l: 0, d: 0, hist: [] };
    console.log(`Создан администратор ${login}`);
  } else if (process.env.ADMIN_PASSWORD_RESET === '1') {
    u.salt = crypto.randomBytes(16).toString('hex');
    u.hash = crypto.scryptSync(pw, u.salt, 64).toString('hex');
    console.log(`Пароль администратора ${login} сброшен`);
  }
  u.admin = true; u.blocked = false;
})();
let saveTimer = null;
function save() { if (!saveTimer) saveTimer = setTimeout(flush, 300); }
function flush() {
  clearTimeout(saveTimer); saveTimer = null;
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { try { flush(); } catch (e) {} process.exit(0); });
flush();

/* ---------------- helpers ---------------- */
const now = () => Date.now();
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const LOGIN_RE = /^[A-Za-zА-Яа-яЁё0-9_-]{3,20}$/;

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function isHttps(req) { return req.headers['x-forwarded-proto'] === 'https' || !!req.socket.encrypted; }
function sessionCookie(req, token, maxAge) {
  return `dbm_s=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${isHttps(req) ? '; Secure' : ''}`;
}
function send(res, code, obj, headers) {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers || {}));
  res.end(JSON.stringify(obj));
}
const fail = (res, code, msg) => send(res, code, { error: msg });
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > 16384) { reject(new Error('too big')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
function clientIp(req) { return String(req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(); }

/* ---------------- auth ---------------- */
function newSession(uid) {
  const token = crypto.randomBytes(32).toString('hex');
  db.sessions[sha(token)] = { uid, exp: now() + SESSION_DAYS * 864e5 };
  save();
  return token;
}
function currentUser(req) {
  const token = parseCookies(req).dbm_s;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const s = db.sessions[sha(token)];
  if (!s || s.exp < now()) return null;
  const u = db.users[s.uid];
  if (!u || u.blocked) return null;
  if (s.exp - now() < (SESSION_DAYS - 1) * 864e5) { s.exp = now() + SESSION_DAYS * 864e5; save(); }
  if (!u.lastSeen || now() - u.lastSeen > 60e3) { u.lastSeen = now(); save(); }
  return u;
}
function killSessions(uid, exceptHash) {
  for (const [k, s] of Object.entries(db.sessions)) if (s.uid === uid && k !== exceptHash) delete db.sessions[k];
  save();
}
function killStreams(uid) {
  const set = streams.get(uid);
  if (!set) return;
  for (const res of set) { try { res.write('event: logout\ndata: {}\n\n'); res.end(); } catch (e) {} }
  streams.delete(uid);
}
function genPassword() {
  const a = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = ''; for (let i = 0; i < 10; i++) s += a[crypto.randomInt(a.length)];
  return s;
}
const failed = new Map(); // ip -> {n, t}
function tooManyFails(ip) {
  const f = failed.get(ip);
  if (!f) return false;
  if (now() - f.t > 10 * 60e3) { failed.delete(ip); return false; }
  return f.n >= 10;
}
function noteFail(ip) {
  const f = failed.get(ip);
  if (!f || now() - f.t > 10 * 60e3) failed.set(ip, { n: 1, t: now() }); else f.n++;
}
function me(u) {
  return { name: u.name, w: u.w || 0, l: u.l || 0, d: u.d || 0, hist: u.hist || [], created: u.created, admin: !!u.admin };
}

/* ---------------- tables ---------------- */
function genCode() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s;
  do { s = ''; for (let i = 0; i < 5; i++) s += a[crypto.randomInt(a.length)]; } while (db.tables[s]);
  return s;
}
function status(t) {
  if (t.closed) return 'closed';
  if (!t.b || !t.g) return 'waiting';
  return t.g.ov ? 'over' : 'playing';
}
const seatOf = (t, uid) => (t.a === uid ? 'A' : t.b === uid ? 'B' : null);
const pub = u => (u ? { name: u.name, w: u.w || 0, l: u.l || 0, d: u.d || 0 } : null);

function tableView(t, uid) {
  const seat = seatOf(t, uid);
  const v = {
    code: t.code, rev: t.rev, seat, status: status(t), opts: t.opts,
    players: { A: pub(db.users[t.a]), B: pub(db.users[t.b]) },
    online: { A: isOnline(t.a), B: isOnline(t.b) },
    closedBy: t.closedBy || null,
  };
  if (t.g) {
    const G = E.clone(t.g);
    delete G.ack; delete G.er; delete G.ak; delete G.bk;
    for (const s of ['A', 'B']) if (s !== seat) G.h[s] = G.h[s].map(() => 'XX');
    G.dk = G.dk.map((c, i) => (i === 0 ? c : 'XX'));
    if (G.ev && G.ev.t === 'bribe' && G.ev.by !== seat) G.ev.c = [];
    v.g = G;
  }
  return v;
}
function summary(t, uid) {
  const seat = seatOf(t, uid);
  const oppId = seat === 'A' ? t.b : seat === 'B' ? t.a : t.a;
  const st = status(t);
  return {
    code: t.code, status: st, opts: t.opts, seat,
    host: pub(db.users[t.a]), opp: pub(db.users[oppId]), oppOnline: isOnline(oppId),
    myTurn: !!(seat && st === 'playing' && E.activeSeat(t.g) === seat),
    score: t.g ? t.g.sc : null, upd: t.upd,
  };
}
function lobbyFor(uid) {
  const open = [], mine = [];
  for (const t of Object.values(db.tables)) {
    if (t.closed) continue;
    if (t.a === uid || t.b === uid) mine.push(summary(t, uid));
    else if (status(t) === 'waiting') open.push(summary(t, uid));
  }
  open.sort((x, y) => y.upd - x.upd);
  mine.sort((x, y) => (y.myTurn - x.myTurn) || (y.upd - x.upd));
  return { open: open.slice(0, 40), mine };
}
function activeCount(uid) {
  return Object.values(db.tables).filter(t => !t.closed && (t.a === uid || t.b === uid)).length;
}
function countResult(t) {
  const g = t.g;
  if (!g || !g.ov || t.counted === g.gn) return;
  t.counted = g.gn;
  const ua = db.users[t.a], ub = db.users[t.b];
  if (!ua || !ub) return;
  const res = g.ov === 'D' ? ['d', 'd'] : g.ov === 'A' ? ['w', 'l'] : ['l', 'w'];
  const apply = (u, r, opp) => {
    u[r] = (u[r] || 0) + 1;
    u.hist = [{ opp: opp.name, r, at: now(), m: t.opts.m, by: t.forfeit ? 'forfeit' : '' }].concat(u.hist || []).slice(0, 20);
  };
  apply(ua, res[0], ub); apply(ub, res[1], ua);
}
function touch(t) {
  t.rev = (t.rev || 0) + 1;
  t.upd = now();
  countResult(t);
  save();
  pushTable(t);
  lobbySoon();
}

/* ---------------- event stream (the bus) ---------------- */
const streams = new Map(); // uid -> Set(res)
function isOnline(uid) { const s = uid && streams.get(uid); return !!(s && s.size); }
function push(uid, event, data) {
  const set = uid && streams.get(uid);
  if (!set) return;
  const msg = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of set) { try { res.write(msg); } catch (e) {} }
}
function pushTable(t) { for (const uid of [t.a, t.b]) if (uid) push(uid, 'table', tableView(t, uid)); }
let lobbyTimer = null;
function lobbySoon() {
  if (lobbyTimer) return;
  lobbyTimer = setTimeout(() => {
    lobbyTimer = null;
    for (const uid of streams.keys()) push(uid, 'lobby', lobbyFor(uid));
  }, 120);
}
function presenceChanged(uid) {
  for (const t of Object.values(db.tables)) {
    if (t.closed || (t.a !== uid && t.b !== uid)) continue;
    const opp = t.a === uid ? t.b : t.a;
    if (opp) push(opp, 'table', tableView(t, opp));
  }
  lobbySoon();
}
setInterval(() => {
  for (const set of streams.values()) for (const res of set) { try { res.write(': ping\n\n'); } catch (e) {} }
}, 20000);

function openStream(req, res, u) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  res.write('retry: 3000\n\n');
  const wasOnline = isOnline(u.id);
  if (!streams.has(u.id)) streams.set(u.id, new Set());
  streams.get(u.id).add(res);
  res.write(`event: me\ndata: ${JSON.stringify(me(u))}\n\n`);
  res.write(`event: lobby\ndata: ${JSON.stringify(lobbyFor(u.id))}\n\n`);
  if (!wasOnline) presenceChanged(u.id);
  req.on('close', () => {
    const set = streams.get(u.id);
    if (set) { set.delete(res); if (!set.size) { streams.delete(u.id); presenceChanged(u.id); } }
    if (db.users[u.id]) { u.lastSeen = now(); save(); }
  });
}

/* ---------------- static files ---------------- */
const STATIC = {
  '/': ['public/index.html', 'text/html; charset=utf-8'],
  '/index.html': ['public/index.html', 'text/html; charset=utf-8'],
  '/engine.js': ['engine.js', 'text/javascript; charset=utf-8'],
};
function serveStatic(req, res) {
  const entry = STATIC[req.url.split('?')[0]];
  if (!entry) return false;
  fs.readFile(path.join(__dirname, entry[0]), (err, buf) => {
    if (err) { res.writeHead(500); res.end('read error'); return; }
    res.writeHead(200, { 'Content-Type': entry[1], 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(buf);
  });
  return true;
}

/* ---------------- API ---------------- */
async function api(req, res, url) {
  const p = url.pathname;
  const isPost = req.method === 'POST';
  let body = {};
  if (isPost) {
    if (!String(req.headers['content-type'] || '').startsWith('application/json')) return fail(res, 415, 'Нужен JSON');
    try { body = await readBody(req); } catch (e) { return fail(res, 400, 'Неверный запрос'); }
    if (!body || typeof body !== 'object') body = {};
  }

  if (p === '/api/register' && isPost) {
    const ip = clientIp(req);
    if (tooManyFails(ip)) return fail(res, 429, 'Слишком много попыток. Подожди 10 минут');
    const login = String(body.login || '').trim(), pw = String(body.password || '');
    if (!LOGIN_RE.test(login)) return fail(res, 400, 'Логин: 3–20 символов, буквы, цифры, _ или -');
    if (pw.length < 6 || pw.length > 100) return fail(res, 400, 'Пароль: от 6 символов');
    const id = login.toLowerCase();
    if (db.users[id]) return fail(res, 409, 'Такой логин уже занят');
    const salt = crypto.randomBytes(16).toString('hex');
    db.users[id] = { id, name: login, salt, hash: hashPw(pw, salt), created: now(), w: 0, l: 0, d: 0, hist: [] };
    const token = newSession(id);
    return send(res, 200, { me: me(db.users[id]) }, { 'Set-Cookie': sessionCookie(req, token, SESSION_DAYS * 86400) });
  }

  if (p === '/api/login' && isPost) {
    const ip = clientIp(req);
    if (tooManyFails(ip)) return fail(res, 429, 'Слишком много попыток. Подожди 10 минут');
    const id = String(body.login || '').trim().toLowerCase(), pw = String(body.password || '');
    const u = db.users[id];
    const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(pw, u.salt), 'hex'), Buffer.from(u.hash, 'hex'));
    if (!ok) { noteFail(ip); return fail(res, 401, 'Неверный логин или пароль'); }
    if (u.blocked) return fail(res, 403, 'Аккаунт заблокирован администратором');
    const token = newSession(id);
    return send(res, 200, { me: me(u) }, { 'Set-Cookie': sessionCookie(req, token, SESSION_DAYS * 86400) });
  }

  if (p === '/api/logout' && isPost) {
    const token = parseCookies(req).dbm_s;
    if (token) { delete db.sessions[sha(token)]; save(); }
    return send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie(req, '', 0) });
  }

  const u = currentUser(req);
  if (!u) return fail(res, 401, 'Нужно войти');

  if (p === '/api/me' && !isPost) return send(res, 200, { me: me(u) });
  if (p === '/api/stream' && !isPost) return openStream(req, res, u);
  if (p === '/api/lobby' && !isPost) return send(res, 200, lobbyFor(u.id));

  if (p === '/api/password' && isPost) {
    const oldPw = String(body.old || ''), newPw = String(body.password || '');
    if (hashPw(oldPw, u.salt) !== u.hash) return fail(res, 400, 'Старый пароль не подходит');
    if (newPw.length < 6 || newPw.length > 100) return fail(res, 400, 'Новый пароль: от 6 символов');
    u.salt = crypto.randomBytes(16).toString('hex');
    u.hash = hashPw(newPw, u.salt);
    killSessions(u.id, sha(parseCookies(req).dbm_s || ''));
    return send(res, 200, { ok: true });
  }

  /* ---------- admin ---------- */
  if (p.startsWith('/api/admin/')) {
    if (!u.admin) return fail(res, 403, 'Нужны права администратора');
    if (p === '/api/admin/overview' && !isPost) {
      const sessCount = {};
      for (const s of Object.values(db.sessions)) if (s.exp > now()) sessCount[s.uid] = (sessCount[s.uid] || 0) + 1;
      const tablesOf = {};
      for (const t of Object.values(db.tables)) if (!t.closed) for (const x of [t.a, t.b]) if (x) tablesOf[x] = (tablesOf[x] || 0) + 1;
      const users = Object.values(db.users).map(x => ({
        id: x.id, name: x.name, created: x.created, lastSeen: x.lastSeen || null, online: isOnline(x.id),
        w: x.w || 0, l: x.l || 0, d: x.d || 0, admin: !!x.admin, blocked: !!x.blocked,
        sessions: sessCount[x.id] || 0, tables: tablesOf[x.id] || 0, me: x.id === u.id,
      })).sort((a, b) => (b.online - a.online) || ((b.lastSeen || b.created) - (a.lastSeen || a.created)));
      const tables = Object.values(db.tables).map(t => ({
        code: t.code, status: status(t), opts: t.opts, upd: t.upd,
        a: db.users[t.a] ? db.users[t.a].name : '—', b: db.users[t.b] ? db.users[t.b].name : null,
        score: t.g ? t.g.sc : null,
      })).sort((x, y) => y.upd - x.upd);
      const games = users.reduce((n, x) => n + x.w + x.l + x.d, 0) / 2;
      return send(res, 200, {
        users, tables,
        stats: { users: users.length, online: users.filter(x => x.online).length, tables: tables.filter(t => t.status !== 'closed').length, games: Math.round(games), uptime: Math.round(process.uptime()) },
      });
    }
    const am = /^\/api\/admin\/users\/([^/]+)\/(block|unblock|reset-password|logout|make-admin|remove-admin|reset-stats|delete)$/.exec(p);
    if (am && isPost) {
      let tid; try { tid = decodeURIComponent(am[1]).toLowerCase(); } catch (e) { return fail(res, 400, 'Неверный адрес'); }
      const target = db.users[tid];
      if (!target) return fail(res, 404, 'Пользователь не найден');
      const op = am[2];
      const self = target.id === u.id;
      if (self && ['block', 'remove-admin', 'delete'].includes(op)) return fail(res, 400, 'С собственным аккаунтом так нельзя');
      let extra = {};
      switch (op) {
        case 'block': target.blocked = true; killSessions(target.id); killStreams(target.id); presenceChanged(target.id); break;
        case 'unblock': target.blocked = false; break;
        case 'logout': killSessions(target.id, self ? sha(parseCookies(req).dbm_s || '') : null); if (!self) { killStreams(target.id); presenceChanged(target.id); } break;
        case 'reset-password': {
          const pw = genPassword();
          target.salt = crypto.randomBytes(16).toString('hex');
          target.hash = hashPw(pw, target.salt);
          if (!self) { killSessions(target.id); killStreams(target.id); presenceChanged(target.id); }
          extra = { password: pw };
          break;
        }
        case 'make-admin': target.admin = true; break;
        case 'remove-admin': target.admin = false; break;
        case 'reset-stats': target.w = 0; target.l = 0; target.d = 0; target.hist = []; break;
        case 'delete': {
          killSessions(target.id); killStreams(target.id);
          for (const [code, t] of Object.entries(db.tables)) {
            if (t.a !== target.id && t.b !== target.id) continue;
            const other = t.a === target.id ? t.b : t.a;
            delete db.tables[code];
            if (other) push(other, 'table_gone', { code });
          }
          delete db.users[target.id];
          break;
        }
      }
      save(); lobbySoon();
      if (db.users[target.id] && !target.blocked) push(target.id, 'me', me(target));
      return send(res, 200, Object.assign({ ok: true }, extra));
    }
    const tm = /^\/api\/admin\/tables\/([A-Za-z0-9]{5})\/delete$/.exec(p);
    if (tm && isPost) {
      const t = db.tables[tm[1].toUpperCase()];
      if (!t) return fail(res, 404, 'Стол не найден');
      delete db.tables[t.code];
      for (const x of [t.a, t.b]) if (x) push(x, 'table_gone', { code: t.code });
      save(); lobbySoon();
      return send(res, 200, { ok: true });
    }
    return fail(res, 404, 'Нет такого адреса');
  }

  if (p === '/api/tables' && isPost) {
    if (activeCount(u.id) >= MAX_ACTIVE_TABLES) return fail(res, 400, `Не больше ${MAX_ACTIVE_TABLES} столов одновременно. Закрой старые`);
    const code = genCode();
    const t = { code, a: u.id, b: null, opts: { m: body.m === 't' ? 't' : 'p', ar: body.ar ? 1 : 0 }, g: null, created: now(), upd: now(), rev: 0, closed: false };
    db.tables[code] = t;
    touch(t);
    return send(res, 200, { view: tableView(t, u.id) });
  }

  const m = /^\/api\/tables\/([A-Za-z0-9]{5})(?:\/(join|act|gift|leave))?$/.exec(p);
  if (m) {
    const t = db.tables[m[1].toUpperCase()];
    if (!t) return fail(res, 404, 'Стол не найден. Проверь код');
    const op = m[2];
    const seat = seatOf(t, u.id);

    if (!op && !isPost) return send(res, 200, { view: tableView(t, u.id) });

    if (op === 'join' && isPost) {
      if (seat) return send(res, 200, { view: tableView(t, u.id) });
      if (t.closed) return fail(res, 410, 'Этот стол уже закрыт');
      if (t.b) return fail(res, 409, 'За столом уже двое');
      if (activeCount(u.id) >= MAX_ACTIVE_TABLES) return fail(res, 400, `Не больше ${MAX_ACTIVE_TABLES} столов одновременно. Закрой старые`);
      t.b = u.id;
      t.g = E.fresh({ m: t.opts.m, ar: t.opts.ar }, null);
      touch(t);
      return send(res, 200, { view: tableView(t, u.id) });
    }

    if (!seat) return fail(res, 403, 'Ты не за этим столом');

    if (op === 'act' && isPost) {
      if (t.closed) return fail(res, 410, 'Стол закрыт');
      if (!t.g) return fail(res, 400, 'Ждём второго игрока');
      const a = body.a && typeof body.a === 'object' ? Object.assign({}, body.a) : null;
      if (!a) return fail(res, 400, 'Непонятный ход');
      delete a.force;
      if (a.t === 'new') { a.m = t.opts.m; a.ar = t.opts.ar; }
      const r = E.apply(t.g, seat, a);
      if (r.err) return fail(res, 400, r.err);
      t.g = r.G;
      touch(t);
      return send(res, 200, { view: tableView(t, u.id) });
    }

    if (op === 'gift' && isPost) {
      const opp = seat === 'A' ? t.b : t.a;
      if (opp) push(opp, 'gift', { code: t.code, from: u.name, i: Number(body.i) | 0 });
      return send(res, 200, { ok: true });
    }

    if (op === 'leave' && isPost) {
      const st = status(t);
      if (st === 'waiting' && seat === 'A') {
        delete db.tables[t.code];
        save(); lobbySoon();
        return send(res, 200, { ok: true, deleted: true });
      }
      if (st === 'playing') {
        const g = t.g, win = E.other(seat);
        g.ov = win; g.sc[win]++; g.v++;
        g.ev = { n: g.ev.n + 1, t: 'forfeit', by: seat, c: [] };
        t.forfeit = true;
      }
      t.closed = true; t.closedBy = seat;
      touch(t);
      return send(res, 200, { ok: true });
    }
  }
  return fail(res, 404, 'Нет такого адреса');
}

/* ---------------- cleanup ---------------- */
setInterval(() => {
  const t0 = now();
  let changed = false;
  for (const [k, s] of Object.entries(db.sessions)) if (s.exp < t0) { delete db.sessions[k]; changed = true; }
  for (const [code, t] of Object.entries(db.tables)) {
    const age = t0 - (t.upd || t.created);
    const st = status(t);
    if ((st === 'waiting' && age > 2 * 864e5) || (st === 'closed' && age > 3 * 864e5) || age > 21 * 864e5) { delete db.tables[code]; changed = true; }
  }
  if (changed) { save(); lobbySoon(); }
}, 60 * 60e3);

/* ---------------- server ---------------- */
const server = http.createServer((req, res) => {
  res.setHeader('Referrer-Policy', 'same-origin');
  const url = new URL(req.url, 'http://x');
  if (url.pathname === '/healthz') { res.writeHead(200); res.end('ok'); return; }
  if (url.pathname.startsWith('/api/')) {
    api(req, res, url).catch(e => { console.error(e); if (!res.headersSent) fail(res, 500, 'Ошибка сервера'); });
    return;
  }
  if (req.method === 'GET' && serveStatic(req, res)) return;
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Не найдено');
});
server.keepAliveTimeout = 65000;
server.listen(PORT, () => console.log(`Дурак: Black Market — сервер на порту ${PORT}, данные в ${DATA_DIR}`));
