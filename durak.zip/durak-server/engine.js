'use strict';
/* Дурак: Black Market — игровой движок. Общий для сервера и браузера. */
/*ENGINE-START*/
const RANKS='6789TJQKA', SUITS='shdc';
const rk=c=>RANKS.indexOf(c[0]), st=c=>c[1];
const other=s=>s==='A'?'B':'A';
const clone=o=>JSON.parse(JSON.stringify(o));

function fresh(opts, prev){
  const dk=[];
  for(const s of SUITS) for(const r of RANKS) dk.push(r+s);
  for(let i=dk.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[dk[i],dk[j]]=[dk[j],dk[i]];}
  const tc=dk[0], tr=st(tc);
  const h={A:[],B:[]};
  for(let i=0;i<6;i++){h.A.push(dk.pop());h.B.push(dk.pop());}
  const low=s=>{const t=h[s].filter(c=>st(c)===tr).map(rk);return t.length?Math.min(...t):99;};
  const la=low('A'), lb=low('B');
  const at= la<lb?'A': lb<la?'B': (Math.random()<.5?'A':'B');
  const g={
    v: Math.max((prev?prev.v:0)+1, Date.now()),
    m: opts.m==='t'?'t':'p', ar: opts.ar?1:0,
    dk, tr, tc, h, tb:[], at, df:other(at), tk:0,
    pw:{A:{k:1,b:1,f:1},B:{k:1,b:1,f:1}},
    out:0, ov:null, sc: prev&&prev.sc ? clone(prev.sc) : {A:0,B:0},
    ev:{n:(prev&&prev.ev?prev.ev.n:0)+1, t:'deal', by:at, c:[]},
    gn:(prev&&prev.gn||0)+1
  };
  if(prev){ for(const k of ['ack','er','ak','bk']) if(prev[k]!==undefined) g[k]=clone(prev[k]); }
  return g;
}

function beats(tr,d,a,docs){
  if(st(d)===st(a)){ if(docs && st(a)!==tr) return true; return rk(d)>rk(a); }
  return st(d)===tr && st(a)!==tr;
}
function canThrow(G,c){
  if(G.ov) return false;
  if(G.tb.length>=6) return false;
  const und=G.tb.filter(p=>!p.d).length;
  if(und>=G.h[G.df].length) return false;
  if(!G.tb.length) return true;
  const r=c[0];
  return G.tb.some(p=>p.a[0]===r || (p.d&&p.d[0]===r));
}
function canTransfer(G,c){
  return G.m==='t' && !G.ov && !G.tk && G.tb.length>0 && G.tb.length<6 &&
    G.tb.every(p=>!p.d) && G.tb.every(p=>p.a[0]===c[0]) &&
    G.h[G.at].length>=G.tb.length+1;
}
function anyThrow(G){ return G.h[G.at].some(c=>canThrow(G,c)); }
function activeSeat(G){
  if(!G||G.ov) return null;
  if(G.tk) return G.at;
  if(G.tb.some(p=>!p.d)) return G.df;
  return G.at;
}
function endBout(G,taken){
  const cards=[];
  for(const p of G.tb){ cards.push(p.a); if(p.d) cards.push(p.d); }
  if(taken) G.h[G.df].push(...cards); else G.out+=cards.length;
  G.tb=[]; G.tk=0;
  const draw=s=>{ while(G.h[s].length<6 && G.dk.length) G.h[s].push(G.dk.pop()); };
  draw(G.at); draw(G.df);
  G.ev={n:G.ev.n+1, t:taken?'take':'bito', by:taken?G.df:G.at, c:cards};
  if(!G.dk.length){
    const a0=!G.h.A.length, b0=!G.h.B.length;
    if(a0||b0){
      G.ov = a0&&b0 ? 'D' : a0 ? 'A' : 'B';
      if(G.ov!=='D') G.sc[G.ov]++;
      return;
    }
  }
  if(!taken){ const t=G.at; G.at=G.df; G.df=t; }
}
function apply(G0,seat,a){
  if(!a||typeof a!=='object'||typeof a.t!=='string') return {err:'Непонятный ход'};
  if(seat!=='A'&&seat!=='B') return {err:'Ты не за столом'};
  if(a.t==='new'){
    if(G0 && !G0.ov && !a.force) return {err:'Партия ещё идёт'};
    return {G:fresh({m:a.m||(G0&&G0.m)||'p', ar:a.ar!==undefined?a.ar:(G0?G0.ar:1)}, G0)};
  }
  if(!G0) return {err:'Карты ещё не розданы'};
  if(G0.ov) return {err:'Партия окончена'};
  const G=clone(G0), me=G.h[seat];
  const c=typeof a.c==='string'?a.c:'';
  const has=()=>c&&me.includes(c);
  const rm=()=>me.splice(me.indexOf(c),1);
  const ev=(t,cs)=>{G.ev={n:G.ev.n+1,t,by:seat,c:cs||[]};};
  switch(a.t){
    case 'atk':{
      if(seat!==G.at) return {err:'Сейчас не твоя атака'};
      if(!has()) return {err:'Нет такой карты'};
      if(!canThrow(G,c)) return {err:'Эту карту сейчас не подкинуть'};
      rm(); G.tb.push({a:c,d:null});
      if(G.tk && !anyThrow(G)) endBout(G,true);
      break;
    }
    case 'def':{
      if(seat!==G.df||G.tk) return {err:'Сейчас не твоя защита'};
      const p=G.tb[a.p|0];
      if(!p||p.d) return {err:'Эта карта уже отбита'};
      if(!has()) return {err:'Нет такой карты'};
      let ok=beats(G.tr,c,p.a,false), usedF=false;
      if(!ok && a.f && G.ar && G.pw[seat].f && beats(G.tr,c,p.a,true)){ok=true;usedF=true;}
      if(!ok) return {err:'Эта карта не бьёт'};
      rm(); p.d=c;
      if(usedF){ G.pw[seat].f=0; ev('docs',[c]); }
      if(G.tb.every(q=>q.d) && !anyThrow(G)) endBout(G,false);
      break;
    }
    case 'tr':{
      if(seat!==G.df) return {err:'Переводит только тот, кто отбивается'};
      if(!has()) return {err:'Нет такой карты'};
      if(!canTransfer(G,c)) return {err:'Перевести нельзя'};
      rm(); G.tb.push({a:c,d:null});
      const t=G.at; G.at=G.df; G.df=t;
      ev('transfer',[c]);
      break;
    }
    case 'take':{
      if(seat!==G.df||G.tk||!G.tb.some(p=>!p.d)) return {err:'Сейчас нечего брать'};
      G.tk=1; ev('taking');
      if(!anyThrow(G)) endBout(G,true);
      break;
    }
    case 'done':{
      if(seat!==G.at||!G.tk) return {err:'Сейчас нечего отдавать'};
      endBout(G,true);
      break;
    }
    case 'bito':{
      if(seat!==G.at||G.tk||!G.tb.length||!G.tb.every(p=>p.d)) return {err:'Ещё не всё отбито'};
      endBout(G,false);
      break;
    }
    case 'krysha':{
      if(!G.ar||!G.pw[seat].k) return {err:'Крыша уже использована'};
      if(seat!==G.df||G.tk) return {err:'Крыша работает только в защите'};
      const i=a.p|0, p=G.tb[i];
      if(!p||p.d) return {err:'Выбери неотбитую карту'};
      if(st(p.a)===G.tr) return {err:'Козырь крышей не прикрыть'};
      G.tb.splice(i,1); G.out++; G.pw[seat].k=0; ev('krysha',[p.a]);
      if(!G.tb.length) endBout(G,false);
      else if(G.tb.every(q=>q.d) && !anyThrow(G)) endBout(G,false);
      break;
    }
    case 'bribe':{
      if(!G.ar||!G.pw[seat].b) return {err:'Взятка уже использована'};
      if(!G.dk.length) return {err:'Колода пуста — давать некому'};
      if(!has()) return {err:'Нет такой карты'};
      rm(); G.out++; me.push(G.dk.pop()); G.pw[seat].b=0; ev('bribe',[c]);
      break;
    }
    default: return {err:'Непонятный ход'};
  }
  G.v++;
  return {G};
}
/*ENGINE-END*/
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { RANKS, SUITS, rk, st, other, clone, fresh, beats, canThrow, canTransfer, anyThrow, activeSeat, endBout, apply };
}
